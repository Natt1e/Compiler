package quaternion.Relation;

public interface Relation {

    public String getOp1();

    public String getOp2();

    public String getResult();

}
