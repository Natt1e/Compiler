package table;

public class FuncNickCounter {

    public static String getNickName(String name) {
        return "func." + name;
    }

}
