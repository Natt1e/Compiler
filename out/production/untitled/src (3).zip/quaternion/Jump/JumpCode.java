package quaternion.Jump;

public interface JumpCode {
    public String getLabel();
}
