package quaternion.Label;

public interface Label {
    public String getLabel();
}
