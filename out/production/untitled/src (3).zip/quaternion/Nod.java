package quaternion;

public class Nod implements Quaternion {
}
