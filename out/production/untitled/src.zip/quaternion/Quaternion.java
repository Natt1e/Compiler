package quaternion;

public interface Quaternion {

}
