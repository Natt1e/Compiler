package actuator;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;



public class Actuator {
    public static String path = "mips.txt";
    private static final boolean print = true;
    private static File writefile = new File(path);


    public static void initialization() { //创建mips.txt
        if (!writefile.exists()) {
            try {
                writefile.createNewFile();
                writefile = new File(path);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            writefile.delete();
            try {
                writefile.createNewFile();
                writefile = new File(path);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }//处理文件,若文件不存在则创建,若文件存在则删除重建
        writeToMips(".data");
    }

/*
    public static void generateVarDataArea() {
        ArrayList<Quaternion> globals = CodeGenerator.quaternions;
        HashMap<String, Integer> tempValues = new HashMap<>();
        for (Quaternion global : globals) {
            if (global instanceof Assign) {
                Assign assign = (Assign) global;
                if (isTemp(assign.getPassiver())) { //为临时变量赋值
                    tempValues.put(assign.getPassiver(), getVarValue(assign.getAgent(), tempValues));
                } else { // 为变量赋值
                    if (!AliasTable.isConst(getArrayName(assign.getPassiver()))) {
                        AliasTable.addValue(getArrayName(assign.getPassiver()), getVarValue(assign.getAgent(), tempValues));
                    }
                }
            } else if (global instanceof Add) {
                Add add = (Add) global;
                tempValues.put(add.getResult(), getVarValue(add.getOp1(), tempValues) + getVarValue(add.getOp2(), tempValues));
            } else if (global instanceof Div) {
                Div div = (Div) global;
                tempValues.put(div.getResult(), getVarValue(div.getOp1(), tempValues) / getVarValue(div.getOp2(), tempValues));
            } else if (global instanceof Mod) {
                Mod mod = (Mod) global;
                tempValues.put(mod.getResult(), getVarValue(mod.getOp1(), tempValues) % getVarValue(mod.getOp2(), tempValues));
            } else if (global instanceof Mul) {
                Mul mul = (Mul) global;
                tempValues.put(mul.getResult(), getVarValue(mul.getOp1(), tempValues) * getVarValue(mul.getOp2(), tempValues));
            } else if (global instanceof Sub) {
                Sub sub = (Sub) global;
                tempValues.put(sub.getResult(), getVarValue(sub.getOp1(), tempValues) - getVarValue(sub.getOp2(), tempValues));
            }
        }
        CodeGenerator.quaternions.clear();//清空中间代码，此步已完成全局变量的设置
        printGlobalVarText();
    }



    public static void printGlobalVarText() {
        ArrayList<AliasItem> sort = new ArrayList<>();
        for (AliasItem value : AliasTable.getTable().values()) {
            sort.add(value);
        }
        sort.sort(Comparator.comparingInt(AliasItem :: getAddr));
        for (AliasItem value : sort) {
            if (!value.getIsConst()) {
                StringBuilder content = new StringBuilder(value.getName() + ": .word " + value.getValues().get(0));
                for (int i = 1; i < value.getValues().size(); i++) {
                    content.append(",").append(value.getValues().get(i));
                }
                writeToMips(content.toString());
            }
        }

    }

    public static int getVarValue(String name, HashMap<String, Integer> tempValues) {
        if (isTemp(name)) {
            return tempValues.get(name); //是临时变量直接查表返回
        } else { //变量
            int dimenson = countDimenson(name);
            if (dimenson == 0) {
                if (AddExpor.isPureNum(name)) {
                    return Integer.parseInt(name); //纯数字直接返回
                } else {
                    return CodeGenerator.aliasTable.getSingleValue(name); //变量取值
                }
            } else if (dimenson == 1) { // 一维数组
                ArrayList<Integer> array = CodeGenerator.aliasTable.getValues(getArrayName(name));
                int index = getVarValue(getIndex1(name), tempValues);
                return array.get(index);
            } else { // 二维数组
                ArrayList<Integer> array = CodeGenerator.aliasTable.getValues(getArrayName(name));
                int index1 = getVarValue(getIndex1(name), tempValues);
                int index2 = getVarValue(getIndex2(name), tempValues);
                return array.get(index1 * index2);
            }
        }
    }

    public static int countDimenson(String ident) {
        int count = 0;
        int dirty = 0;
        boolean inIndex = false;
        for (int i = 0; i < ident.length(); i++) {
            if (ident.charAt(i) == '[') {
                if (!inIndex) {
                    inIndex = true;
                } else {
                    dirty++;
                }
            } else if (ident.charAt(i) == ']') {
                if (dirty == 0) {
                    count++;
                    inIndex = false;
                } else {
                    dirty--;
                }
            }
        }
        return count;
    }
 */
    public static String getArrayName(String ident) {
        int index = ident.indexOf("[");
        if (index == -1) {
            return ident;
        }
        return ident.substring(0, index);
    }

    public static String getIndex1(String ident) {
        int begin = ident.indexOf("[");
        StringBuilder index1 = new StringBuilder();
        int dirty = 1;
        for (int i = begin + 1; i < ident.length(); i++) {
            if (ident.charAt(i) == '[') {
                index1.append(ident.charAt(i));
                dirty++;
            } else if (ident.charAt(i) == ']') {
                dirty--;
                if (dirty == 0) {
                    break;
                }
                index1.append(ident.charAt(i));
            } else {
                index1.append(ident.charAt(i));
            }
        }
        return index1.toString();
    }



    public static String getIndex2(String ident) {
        int begin = ident.indexOf("[");
        int dirty = 1;
        int i;
        for (i = begin + 1; i < ident.length(); i++) {
            if (ident.charAt(i) == '[') {
                dirty++;
            } else if (ident.charAt(i) == ']') {
                dirty--;
                if (dirty == 0) {
                    break;
                }
            }
        }
        return getIndex1(ident.substring(i));
    }

    /*
    public static boolean isTemp(String name) {
        return name.indexOf("temp.") == 0;
    }
    */


    public static void writeToMips(String content) {
        if (print) {
            try {
                FileWriter fw = new FileWriter(writefile, true);
                BufferedWriter bw = new BufferedWriter(fw);
                fw.write(content + '\n');
                fw.flush();
                fw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

}
