package quaternion;

public interface BinaryExp {
    public String getOp1();
    public String getOp2();
    public String getResult();
}
